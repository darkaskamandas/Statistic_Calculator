﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace StatisticsCalculator
{
    public class CalculatorPickerItem
    {
        public string Label { get; set; }
        public ContentView Calculator { get; set; }
    }
}
